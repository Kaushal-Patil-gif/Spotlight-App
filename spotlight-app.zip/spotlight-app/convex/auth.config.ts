export default {
  providers: [
    {
      domain: "https://modest-kangaroo-11.clerk.accounts.dev/",
      applicationID: "convex",
    },
  ],
};
